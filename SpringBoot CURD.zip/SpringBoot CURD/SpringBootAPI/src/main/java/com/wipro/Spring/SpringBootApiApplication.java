package com.wipro.Spring;

import com.wipro.Spring.Model.Employee;
import com.wipro.Spring.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApiApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApiApplication.class, args);
	}

	@Autowired
	private EmployeeRepository employeeRepository;
	@Override
	public void run(String... args) throws Exception
	{
		Employee employee= new Employee();
		employee.setFistname("Anjali");
		employee.setLastname("Baviskar");
		employee.setEmail("anjalibaviskar@gmail.com");
		employeeRepository.save(employee);

		Employee employee1= new Employee();
		employee.setFistname("vaishanvi");
		employee.setLastname("patil");
		employee.setEmail("vaishnavipatil@gmail.com");
		employeeRepository.save(employee);

	}
}
